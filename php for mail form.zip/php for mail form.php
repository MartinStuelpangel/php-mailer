 <?php error_reporting(0); ?> 
 
 
    <style>
	   label{
		   font-size:20px;
		   
	   }
	   
	   input[type=text]{
		   width:250px;
		   height:30px;
		   font-size: 100%;
		   
		    
	   }
	   textarea {
		font-size: 100%;
		color:black;
		resize:none;
		}
	   
      .error-box{
		  color:red;
		  background-color:white;
		  border: solid 2px red;
		  padding:4px;
		  width:260px;
		  font-size:14px;
		  font-weight:bold;
	  }
	     .error-box2{
		  color:red;
		  background-color:white;
		  border: solid 2px red;
		  padding:4px;
		  width:280px;
		  font-size:14px;
		  font-weight:bold;
		  
	  }
	  
	  .good-green{
		  color:green;
		  border: solid 2px green;
		  padding:2px;
	  }
	    .good-box{
		  color:green;
		  background-color:white;
		  border: solid 1px green;
		  padding:4px;
		  width:250px;
		  margin-bottom:6px;
	  }
	input[type=submit] {
		background-color:red;
		border: solid 2px black;
		color: white;
		font-size:20px;
		padding: 8px 12px;
		margin: 4px 2px;
		cursor: pointer;
}
	input:hover[type=submit]{
		background-color:white;
		color:red;
	}
    </style>
 <?php
 			  
			 
 ?>
    
    <?php
      if(isset($_POST['submit'])){
        $name = htmlspecialchars(stripslashes(trim($_POST['name'])));
        $subject = htmlspecialchars(stripslashes(trim($_POST['subject'])));
        $email = htmlspecialchars(stripslashes(trim($_POST['email'])));
        $message = htmlspecialchars(stripslashes(trim($_POST['message'])));
		$image_test = strtolower(htmlspecialchars(stripslashes(trim($_POST['image_test']))));
        if(!preg_match("/^[A-Za-z .'-]+$/", $name)){
          $name_error = 'Invalid name. Letters only';
        }
        if(!preg_match("/^[A-Za-z .'-]+$/", $subject)){
          $subject_error = 'Invalid subject. Letters only';
        }
        if(!preg_match("/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/", $email)){
          $email_error = 'Invalid email';
        }
        if(strlen($message) === 0){
          $message_error = 'Please add a message';
        }
		if(!preg_match("/^[A-Za-z .'-]+$/", $image_test)){
          $test_error = 'Letters only';
		  	  
        }
	  }
	  $name_value=$name;
	  $subject_value=$subject;
	  $email_value=$email;
	  $message_value=$message;
	  $image_test_value=$image_test;
	   
	  ?>
   
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
	
	
      <label for="name">Type Your Name:</label><br> 
	  <?php if(isset($name_error))
	  { echo "<div class='error-box'>".$name_error;  $name_value=""; } 
		elseif($name_value!=""){$good_green="good-green";}
		?> 
      <input type="text" name="name" maxlength="40" class="<?php echo $good_green;?>" value="<?php echo $name_value;?>">
	   <?php if(isset($name_error)){echo "</div>";}?><br><br>
	  
	  
	       <label for="subject">Type a Subject:</label><br> 
		   <?php if(isset($subject_error))
		   { echo "<div class='error-box'>".$subject_error;  $subject_value=""; } 
		elseif($subject_value!=""){$good_green2="good-green";}
		   ?> 
      <input type="text" name="subject" maxlength="40" class="<?php echo $good_green2;?>" value="<?php echo $subject_value;?>">
	  <?php if(isset($subject_error)){echo "</div>";}?><br><br>
	  
	  	       <label for="email">Your Email:</label><br> 
			   <?php if(isset($email_error))
			   { echo "<div class='error-box'>".$email_error;  $email_value=""; }
		elseif($email_value!=""){$good_green3="good-green";}
			   ?> 
      <input type="text" name="email" maxlength="40" class="<?php echo $good_green3;?>" value="<?php echo $email_value;?>">
	  <?php if(isset($email_error)){echo "</div>";}?><br><br>
	  
 	  	       <label for="message">Type a Message:</label><br>
			   <?php if(isset($message_error))
			   { echo "<div class='error-box2'>".$message_error;  $message_value=""; } 
				elseif($message_value!=""){$good_green4="good-green";}
			   ?> 
	  <textarea name="message" rows="8" cols="32" maxlength="400"  class="<?php echo $good_green4;?>"><?php echo $message_value;?></textarea> 	
	<?php if(isset($message_error)){echo "</div>";}?><br><br>	  

      <label for="test_error">Type in the name of this food: B u r r _ _ _</label><br> <!--change to your word-->
 
	 
	   <?php if(isset($test_error)) $image_test_value=""; ?>
	  <?php if(isset($image_test)) 
				if ($image_test !== "burrito"){  //change burrito to your word
				echo "<div class='error-box'>Wrong food type</div>";//change message to what you like
				}
				else{
					echo "<div class='good-box'>You are correct! <br>A burrito is an awesome food!</div>"; //change message to what you like
					$good_green5="good-green";
				}?>
		<div class="flex-container">		
				<input type="text" name="image_test" maxlength="7" value="<?php echo $image_test_value;?>" class="<?php echo $good_green5;?>"><br>
				
				
	   <img src="images/image-b.png">
	   </div>
	  
      <input type="submit" name="submit" value="Send Message">
      <?php 
		 if(isset($_POST['submit']) && !isset($name_error) && !isset($subject_error) && !isset($email_error) && !isset($message_error) && $image_test=="burrito"){  //change burrito to your word
          $to = 'me@me.com'; // use your email
		  $body = " Name: $name\n E-mail: $email\n Message:\n $message";
		  
		  $headers = "From: $name <$email>\r\n";
		  $headers .="Reply-To: <$email>\r\n";
		  
		  
          if(mail($to, $subject, $body, $headers)){
			   echo "<meta http-equiv='refresh' content=\"0; url=mail-result/yes.php\">";
            
			}else{
				echo "<meta http-equiv='refresh' content=\"0; url=mail-result/no.php\">";
            
			  }
        }   
      ?>
 
	  
	  
    </form> 
