<?php
 
 
header( "refresh:6;url= your url or file" ); // redirects to your choice 
?>


<style>
a{
	color:black;
	font-size:24px;
}
a:hover{
	color:red;
}
h2{
	color:red;
	font-weight:bold;
	font-size:32px;
}

</style>

<div style="display: block;
    margin-left: auto;
    margin-right: auto;
	width:50%;
	margin-top:10%;">
<h2>Something went wrong, mail not sent, sorry</h2>
<img src="your image"/><br> <!--your image choice--->
<a href="../your file">Click here to try again</a><!-- redirect to your choice-->
</div>