<?php
 
 
header( "refresh:3;url=   " );  // redirects to your choice 
?>
<style>
a{
	color:black;
	font-size:24px;
}
a:hover{
	color:red;
}
h2{
	color:green;
	font-weight:bold;
	font-size:32px;
}

</style>

<div style="display: block;
    margin-left: auto;
    margin-right: auto;
	width:50%;
	margin-top:10%;">
<h2>Mail Sent!</h2>
<img src=" "><br><!--your image choice--->
<a href="   ">Click here if not redirected</a><!-- redirect to your choice-->
</div>